### This forecast solution uses Prophet open-source software released by Facebook's data science team.

To use please follow https://github.com/facebook/prophet to install the package in python.

In the prophet.py file it's the implementation of the model with a grid search for the trend flexibility and seasonalities. The main function is run().

In the notebook you can find its application on the final project of Business Cases with Data Science of NOVA IMS.

 
