from fbprophet import Prophet
from fbprophet.diagnostics import performance_metrics
from fbprophet.diagnostics import cross_validation
import numpy as np
import pandas as pd
import itertools
from tqdm import tqdm

class prophet:

    def __init__(self, data, freq=None, periods=None, market_share=None):
        self.demand = data  # Pandas Dataframe with y values from history
        self.freq = freq  # Any valid frequency for pd.date_range, such as 'D' or 'M'.
        self.periods = periods  # Int number of periods to forecast forward.

    # Prophet Model
    ##################################################################################
    def run_model(self, trend_flexibility, add_seasonality, trend_growth='linear'):
        """
            Main function for training and testing.

            :param trend_growth: String 'linear' or 'logistic' to specify a linear or logistic
            trend. And 'flat' for no trend.
            :param trend_flexibility: Int number between 0 and 1. Helps adjust the strength of the trend.
             Increasing the value will make the trend more flexible.
            :return Dataframe with predictions, model object and the mean error.
        """

        # Prepare data to Prophet requirements
        ###################################################################
        # Create column ds with index (demand date)
        demand = self.demand
        demand['ds'] = demand.index


        # Train model
        #####################################################################
        if self.freq is not 'D' or 'B':
            model = Prophet(growth=trend_growth, changepoint_prior_scale=trend_flexibility, weekly_seasonality=False)
        else:
            model = Prophet(growth=trend_growth, changepoint_prior_scale=trend_flexibility)
            
            
        # Add seasonality
        if add_seasonality:
            if len(add_seasonality) == 2:
                model.add_seasonality(name='monthly', period=30.5, fourier_order=5)
                model.add_seasonality(name='quarterly', period=91.5, fourier_order=7)
            if add_seasonality == 'monthly':
                model.add_seasonality(name='monthly', period=30.5, fourier_order=5)
            if add_seasonality == 'quarterly':
                model.add_seasonality(name='quarterly', period=91.5, fourier_order=7)

        # Fit
        model.fit(demand)

        # Predict Test
        ####################################################################

        # Dataframe to predict (including all history)
        # predict() from Prophet only receives dates as a column 'ds' (and other external variables)
        demand_predict = demand.drop(columns=['y'])

        # Dataframe with yhat (y predicted) and the components of the model
        forecast = model.predict(demand_predict)
        
        forecast.set_index('ds', inplace=True) # Set dates as index again

        # Diagnostics - Time series cross validation to measure forecast error using historical data
        train_period = int(len(demand) * 0.6) # Initialize with 60% of the sample
        test_ratio = 0.2
        horizon = int(train_period * test_ratio)

        error = self.evaluation(model, training_period=train_period, forecast_horizon=horizon)
        

        return model, error
    

    # Errors and the model robustness
    def evaluation(self, model, forecast_horizon, training_period=None, prediction_period=None):
        """
        Measure errors based on cross validation (SHF).

            :param model: Prophet model.
            :param training_period: String with pd.Timedelta compatible style.
            The size of the initial training period.
            :param prediction_period: String with pd.Timedelta compatible style.
            Spacing between cutoff dates.
            :param forecast_horizon: String with pd.Timedelta compatible style.
            :return Mean of the error from each fold
        """

        # Passing periods to string with Timedelta format
        initial = pd.Timedelta(training_period, unit=self.freq)
        horizon = pd.Timedelta(forecast_horizon, unit=self.freq)

        # Cross validation
        df_cv = cross_validation(model, initial=initial, period=prediction_period, horizon=horizon)

        df_p = performance_metrics(df_cv)

        # WAPE per fold
        def ewm_error(fold):
            numerator = np.abs(fold.y - fold.yhat) 
            denominator = np.abs(fold.y)

            wape = np.sum(numerator) / np.sum(denominator)
            return wape
        errors_fold = df_cv.groupby('cutoff').apply(ewm_error)

        # Weighted mean of fold errors (giving more weight to the most recent folds)
        mean_wape = errors_fold.ewm(alpha=0.1, adjust=True).mean()[-1:].iloc[0]

        std = np.std(errors_fold)

        return mean_wape

    def check_best(self, df):
        """
        Find min error.

        :param df: DataFrame with grid search results.
        :return: Dataframe with best model.
        """
        df_best = pd.DataFrame(columns=df.columns)
        idxmin = df['error_predictions'].idxmin()
        if np.isnan(idxmin):
            idxmin = df.index[0]
        row = df.loc[idxmin]
        df_best = df_best.append(row)

        return df_best
    
    def grid_search (self, lst_flexibility, lst_seasonality):
        """
        Grid search for the trend flexibility and types of seasonality adding to the yearly one in the prophet model default.
        
        The trend_flexibility adjusts the strength of the sparse prior using the input argument changepoint_prior_scale from prophet.
        Stregth varies from 0 to 1: Too much flexibility can result on overfitting.
 
        :param lst_flexibility: List with rates to try.
        :param lst_seasonality: List with seasonalities to try.
        
        :return: List with results.
        """

        results = list()

        for season in lst_seasonality:
            for flex in lst_flexibility:
                model, err = self.run_model(trend_flexibility = flex, add_seasonality = season)
                hyper_par = (flex, season)
                results.append((model, err, hyper_par))

        return results
    

    def run(self):
        """
        Main function to get best model.

        :return: Dataframe with forecast Dataframe (containing the y, yhat, confidence interval, error and hyperparameters used)
        """
        
        lst_flex = [0.05, 0.1, 0.2]
        lst_seasonality = [[],'monthly', 'quarterly', ['monthly', 'quarterly']]
        
        # if history less than 6 months (~27 semanas) or proportion of zeros bigger than 70% or history without zeros less than 3 months
        # apply a shorter grid search to do a simpler model with less parameters to estimate
        zero_sales = len(self.demand[self.demand['y'] == 0])
        history = len(self.demand)
        if history <= 27 or (zero_sales/history) > 0.7 or (history-zero_sales) <= 14:
            lst_flex = [0.05, 0.1]
            lst_seasonality = [[],'monthly']
        
        # less than 14 weeks (~ 3 months) - basic model
        if history <= 14:
            lst_flex = [0.05]
            lst_seasonality = [[]]
        
        results = self.grid_search(lst_flex, lst_seasonality)

        # Results post-processing
        results_df = pd.DataFrame(results)
        results_df.columns = ['model',
                              'error_predictions',
                              'hyper_parameters']

        best = self.check_best(results_df)

            
        forecast_future = self.get_forecasts(best.iloc[0]['model'])
        forecast_future = forecast_future[['ds','yhat', 'yhat_lower', 'yhat_upper']]
        forecast_future['WAPE'] = best.iloc[0]['error_predictions']
        
        forecast_future['trend_flexibility'] = best.iloc[0]['hyper_parameters'][0]
        
        seasonality = [best.iloc[0]['hyper_parameters'][1]] * len(forecast_future)
        forecast_future['seasonality_types'] = seasonality
        
        forecast_future.set_index('ds', inplace=True) # Set dates as index again
        
        return pd.concat([forecast_future, self.demand['y']], ignore_index=False, axis=1)


    # Future Forecast
    #######################################################################


    def get_forecasts(self, model):
        """
        Get future Forecast.

        :param model: Model object
        :return out_forecast: Dataframe with forecast
        """

        # Out of sample forecasting
        ############################################################################
        # Days to extend into the future + history
        future = model.make_future_dataframe(periods=self.periods, freq=self.freq)

        
        # Predictions with components (like confidence interval, trend and seasonality) (see Prophet documentation to know more)
        out_forecast = model.predict(future)

        return out_forecast
    
